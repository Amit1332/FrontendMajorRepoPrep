import MockTest from "./MockTest/MockTest";
import VideoTutorial from "./VideoTutorial/VideoTutorial";







export {
    MockTest,
    VideoTutorial
}