import React from 'react'
import card7 from "../../../assets/snipping/card7.png"
import card8 from "../../../assets/snipping/card8.png"
import card9 from "../../../assets/snipping/card9.png"
import card10 from "../../../assets/snipping/card10.png"
import card11 from "../../../assets/snipping/card11.png"




const NinthSec = () => {
  return (
    <div className='fifth-sec ninth-sec'>
<div className="card-img">
<img src={card7} alt="" />
<img src={card8} alt="" />

<img src={card9} alt="" />
<img src={card10} alt="" />
<img src={card11} alt="" />




</div>
    </div>
  )
}

export default NinthSec