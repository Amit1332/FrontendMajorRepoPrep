import React from 'react'
import card4 from "../../../assets/snipping/card4.png"
import card5 from "../../../assets/snipping/card5.png"
import card6 from "../../../assets/snipping/card6.png"

const SeventhSec = () => {
  return (
    <div className='sevent-sec'>
        <h1>Mentors & Instructors</h1>

<div className="card-img">
<img src={card4} alt="" />
<img src={card5} alt="" />

<img src={card6} alt="" />



</div>
    </div>
  )
}

export default SeventhSec