import React from 'react'
import feature from '../../../assets/images/Feature.webp'

const Feature = () => {
  return (
    <div className='feature'>
        <img src={feature} alt="" />
    </div>
  )
}

export default Feature