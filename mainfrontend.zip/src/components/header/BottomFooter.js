import React from 'react'

const BottomFooter = () => {
  return (
    <div className='bottom-footer'>
    Need Help? Talk to us on  079 6900 2111 or &nbsp;<span> Request Callback</span>
    </div>
  )
}

export default BottomFooter