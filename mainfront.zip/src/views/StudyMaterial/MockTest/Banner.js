import React from 'react'

const Banner = () => {
  return (
    <div className='banner'>
        <h1>Mock Test</h1>
        <p>Technical and Aptitude Test is a very important process of most of the placement tests. Crack your next placement with series of PrepBytes practice and mock tests. Practice subject-wise and company-wise tests. Take real-time mock tests with other students and test your preparation.</p>

    </div>
  )
}

export default Banner