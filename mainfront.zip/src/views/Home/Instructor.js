import React from 'react'

const Instructor = () => {
  return (
    <div className='instructor'>
        <img src="/images/home1.webp" alt="" />

    </div>
  )
}

export default Instructor