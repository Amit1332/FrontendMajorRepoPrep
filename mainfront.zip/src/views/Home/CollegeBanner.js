import React from 'react'

const CollegeBanner = () => {
  return (
    <div className='college-banner'>
        <div className="card">
            <h1>Want to Represent Your College</h1>
                <h2>Join Prepbytes Campus Buisness Manager Internship Program</h2>

                <div className="button"> Join Now</div>
        </div>

    </div>
  )
}

export default CollegeBanner