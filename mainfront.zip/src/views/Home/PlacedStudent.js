import React from 'react'

const PlacedStudent = () => {
  return (
    <div className='placed-student'>
        <img src="/images/home2.png" alt="" />

    </div>
  )
}

export default PlacedStudent