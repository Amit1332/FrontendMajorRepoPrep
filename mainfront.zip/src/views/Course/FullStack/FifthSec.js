import React from 'react'
import card1 from "../../../assets/snipping/card1.png"
import card2 from "../../../assets/snipping/card2.png"
import card3 from "../../../assets/snipping/card3.png"



const FifthSec = () => {
  return (
    <div className='fifth-sec'>
        <h1>Companies that hire for the roles</h1>

<div className="card-img">
<img src={card1} alt="" />
<img src={card2} alt="" />

<img src={card3} alt="" />



</div>
    </div>
  )
}

export default FifthSec